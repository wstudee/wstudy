package kr.or.ddit.board.controller;

import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ddit.board.service.BoardServiceImpl;
import kr.or.ddit.board.service.IBoardService;
import kr.or.ddit.board.vo.BoardVO;

@WebServlet("/boardInsert")
public class boardInsertServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/board/boardInsert.jsp");
		dispatcher.forward(req, resp);

	}
	
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 서비스 객체 생성
		IBoardService service = BoardServiceImpl.getInstance();
		
		BoardVO bvo = new BoardVO();
		
		String title = req.getParameter("boardTitle");
		String writer = req.getParameter("boardWriter");
		String content = req.getParameter("boardContent");
		
		bvo.setBoardTitle(title);
		bvo.setBoardWriter(writer);
		bvo.setBoardContent(content);
		
		
		int cnt = service.boardInsert(bvo);
		String msg = "";
		
		if(cnt > 0) {
			msg = "성공";
		}else {
			msg= "실패";
		}
		
		String redirectUrl = req.getContextPath() + "/boardMain?msg=" 
								+ URLEncoder.encode(msg, "UTF-8");
		resp.sendRedirect(redirectUrl);
	}
}
