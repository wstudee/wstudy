package kr.or.ddit.board.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ddit.board.service.BoardServiceImpl;
import kr.or.ddit.board.service.IBoardService;
import kr.or.ddit.board.vo.BoardVO;

@WebServlet("/boardView")
public class boardViewServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
	
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 서비스 객체 생성
		IBoardService service = BoardServiceImpl.getInstance();
		
		String boardNo = req.getParameter("boardNo");
		System.out.println("no : " + boardNo);
		// 게시글 한건 조회
		BoardVO boardView = service.getBoardView(boardNo);
		
		req.setAttribute("boardView", boardView);
		
		
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/board/boardView.jsp");
		dispatcher.forward(req, resp);
		
		
	}
	
	
	
	
	
	
	
}
