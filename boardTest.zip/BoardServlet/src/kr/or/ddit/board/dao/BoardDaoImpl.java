package kr.or.ddit.board.dao;

import java.sql.SQLException;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import kr.or.ddit.board.vo.BoardVO;
import kr.or.ddit.util.sqlMapClientFactory;

public class BoardDaoImpl implements IBoardDao {

	private static IBoardDao boardDao;
	
	private SqlMapClient smc;
	
	// 생성자 private 
	private BoardDaoImpl() {
		smc = sqlMapClientFactory.getInstance();
	}
	
	// getInstance 메서드 호출되면 
	// boardDao가 없으면 생성 -> 생성하면서 smc 객체 생성
	// boardDao 있으면 있는 거 가져옴
	public static IBoardDao getInstance() {
		if(boardDao == null) {
			boardDao = new BoardDaoImpl();
		}
		return boardDao;
	}

	/**
	 * 전체 게시판 목록을 조회
	 * @throws SQLException 
	 */
	@Override
	public List<BoardVO> getBoardList() throws Exception {
		List<BoardVO> boardList = (List<BoardVO>) smc.queryForList("board.getBoardList");
		return boardList;
	}

	@Override
	public int boardInsert(BoardVO bvo) throws Exception {
		int cnt = 0;
		
		Object obj = smc.insert("board.boardInsert", bvo);
		
		if(obj == null) {
			cnt = 1;
		}
		
		return cnt;
	}

	/**
	 * 게시글 한 건을 조회하는 메서드
	 */
	@Override
	public BoardVO getBoardView(String boardNo) throws Exception {
		BoardVO bvo = (BoardVO) smc.queryForObject("board.boardView", boardNo);
		return bvo;
	}

	/**
	 * 게시글 수정 메서드
	 * @throws SQLException 
	 */
	@Override
	public int boardUpdate(BoardVO bvo) throws SQLException {
		int result = smc.update("board.boardUpdate", bvo);
		return result;
	}

	@Override
	public int boardDelete(String boardNo) throws Exception {
		int result = smc.update("board.boardDelete", boardNo);
		return result;
	}
	
	

}
