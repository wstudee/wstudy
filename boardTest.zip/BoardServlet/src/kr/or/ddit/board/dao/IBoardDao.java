package kr.or.ddit.board.dao;

import java.sql.SQLException;
import java.util.List;

import kr.or.ddit.board.vo.BoardVO;

public interface IBoardDao {

	public List<BoardVO>  getBoardList() throws Exception ;

	public int boardInsert(BoardVO bvo) throws Exception;

	public BoardVO getBoardView(String boardNo) throws Exception;

	public int boardUpdate(BoardVO bvo) throws SQLException;

	public int boardDelete(String boardNo) throws Exception;

}
