package kr.or.ddit.board.service;

import java.sql.SQLException;
import java.util.List;

import kr.or.ddit.board.controller.boardViewServlet;
import kr.or.ddit.board.dao.BoardDaoImpl;
import kr.or.ddit.board.dao.IBoardDao;
import kr.or.ddit.board.vo.BoardVO;

public class BoardServiceImpl implements IBoardService {
	
	private IBoardDao boardDao;
	private static IBoardService service;

	// 생성자 private
	private BoardServiceImpl() {
		boardDao = BoardDaoImpl.getInstance();
		
	}
	
	// getInstance 메서드 호출되면
	// boardService가 없으면 생성 -> 생성하면서 boardDao 객체 생성
	// boardService 있으면 있는 거 가져옴
	public static IBoardService getInstance() {
		if(service == null) {
			service = new BoardServiceImpl();
		}
		return service;
	}

	// 전체 게시판 목록을 조회하는 메서드
	@Override
	public List<BoardVO> getBoardList() {
		
		List<BoardVO> boardList = null;
		
		try {
			boardList = boardDao.getBoardList();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return boardList;
	}

	@Override
	public int boardInsert(BoardVO bvo) {
		int cnt = 0;
		
		try {
			cnt = boardDao.boardInsert(bvo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return cnt;
	}

	@Override
	public BoardVO getBoardView(String boardNo) {
		BoardVO bvo = null;
		try {
			bvo = boardDao.getBoardView(boardNo);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return bvo;
	}

	@Override
	public int boardUpdate(BoardVO bvo) {
		int result = 0;
		try {
			result = boardDao.boardUpdate(bvo);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public int boardDelete(String boardNo) {
		int result = 0;
		try {
			result = boardDao.boardDelete(boardNo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
