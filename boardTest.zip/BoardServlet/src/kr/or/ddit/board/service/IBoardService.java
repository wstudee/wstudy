package kr.or.ddit.board.service;

import java.util.List;

import kr.or.ddit.board.vo.BoardVO;

public interface IBoardService {

	/**
	 * 전체 게시판 정보를 조회하는 메서드 
	 * @return
	 */
	public List<BoardVO> getBoardList();

	/**
	 * 게시글 등록하는 메서드
	 * @return
	 */
	public int boardInsert(BoardVO bvo);

	/**
	 * 게시글 한건을 조회하는 메서드
	 * @return
	 */
	public BoardVO getBoardView(String boardNo);

	/**
	 * 게시글 수정하는 메서드
	 * @param bvo
	 * @return
	 */
	public int boardUpdate(BoardVO bvo);

	/**
	 * 게시글 삭제하는 메서드
	 * @param boardNo
	 * @return
	 */
	public int boardDelete(String boardNo);
	
	

}
