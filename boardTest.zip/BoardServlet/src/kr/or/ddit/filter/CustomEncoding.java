package kr.or.ddit.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class CustomEncoding implements Filter{
	
	private String encoding; //인코딩 정보
	
	@Override
	public void init(FilterConfig config) throws ServletException {
		if(config.getInitParameter("encoding")==null) { // 인코딩값 세팅 안했으면
			this.encoding = "utf-8"; // default값 
		}else {
			this.encoding = config.getInitParameter("encoding");
			//=> web.xml 에서 <init-param> 안에 encoding값을 ISO-8859-1로 하면
			//   T06_ServletSessionTest.java창 실행시 한글 깨짐
		}
	}
	
	@Override
	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain fc)
			throws IOException, ServletException {
		System.out.println("request 인코딩 설정 : " +  encoding);
		req.setCharacterEncoding(encoding);
		
		System.out.println("response 인코딩 설정 : "+ encoding);
		resp.setCharacterEncoding(encoding);
		
		//위에 인코딩 설정 미리 해줌
		fc.doFilter(req, resp);
	}
	
	@Override
	public void destroy() {
		
	}

}
